<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Form</title>
    <link rel="stylesheet" href="design.css">
</head>
<body>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
<div class="left-container">
</div>
<div class="right-container">
    <div class="right-container__box">
        <div class="right-container-box">
        <h2 class="right-container__h2">Nice to see you!</h2>
            <p class="right-container__p">Enter your email and password to sign in</p>
        </div>
        <div class="input-container">
            <label for="email" class="right-container__label">Email</label>
            <input type="text" class="right-container__input" id="email" name="email" placeholder="Your email address">
            <label for="password" class="right-container__label">Password</label>
            <input type="password" id="password" class="right-container__input" name="password" placeholder="Your password"> 
        </div> 
        <div class="toggle-container">
          <input type="checkbox" class="toggle-box" name="checkbox">
          <label for="checkbox">Remember me</label>
        </div>
        <button class="btn">SIGN IN</button><br><br></button>
        <hr>
        

        <p> dont have an account? </p>
       
        <a href ="student_form.php"> <button class="sgnup">Sign Up?</button>

</div>
</div>
</div>
    </form>
    <a href="../../index.php">Back to List</a>
</body>
</html>





<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <title>LogIn Form</title>
    <link rel="stylesheet" href="design.css">
</head>
<body>
    <form id=login>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
<div class="left-container">
</div>
<div class="right-container">
    <div class="right-container__box">
        <div class="right-container-box">
            <h2 class="right-container__h2">Nice to see you!</h2>
            <p class="right-container__p">Enter your email and password to sign in</p>
        </div>
        <div class="input-container">
            <label for="email" class="right-container__label">Email</label>
            <input type="text" class="right-container__input" id="email" name="email" placeholder="Your email address">
            <label for="password" class="right-container__label">Password</label>
            <input type="password" id="password" class="right-container__input" name="password" placeholder="Your password"> 
        </div> 
        <div class="toggle-container">
          <input type="checkbox" class="toggle-box" name="checkbox">
          <label for="checkbox">Remember me</label>
        </div>
        <button class="btn">SIGN IN</button><br><br></button>
        <hr>
        

        <p> dont have an account? </p>
       
        <a href ="student_form.php"> <button class="sgnup">Sign Up?</button>
    </div>
</div>
</form>


    <a href="../../index.php">Back to List</a>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="script.js"></script>
</body>
</html> -->
