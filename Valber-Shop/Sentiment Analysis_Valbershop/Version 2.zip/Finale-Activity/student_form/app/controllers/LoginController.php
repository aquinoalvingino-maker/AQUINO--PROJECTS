<?php 
session_start();
require_once __DIR__ . '/../../config/database.php';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? ''; 


    if (empty($email) || empty($password)) {
        $errors[] = "Please enter both email and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, email, passwords FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
    
        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
    
            if ($user) {
                if ($password === $user['passwords']) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['email'] = $user['email'];
                    header("Location: ../../../students_crud/index.php");
                    exit;
                } else {
                    $errors[] = "Incorrect password.";
                }
            } else {
                $errors[] = "Email not found.";
            }
        } else {
            $errors[] = "Error executing query.";
        }
    }
}
?>

<?php if (!empty($errors)): ?>
    <div class="errors">
        <?php foreach ($errors as $error): ?>
            <p><?php echo $error; ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
