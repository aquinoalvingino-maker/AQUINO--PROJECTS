$(document).ready(function() {
    loadEmployees();
    loadProjectList();
    loadProjects();

    // Add or Update Student
    $("#employeeForm").submit(function(e) {
        e.preventDefault();
        if(validation()){
            return;
        }else{
        $.post("save.php", $(this).serialize(), function(response) {
            alert(response);
            $("#employeeForm")[0].reset();
            $("#employee_id").val("");
            loadEmployees();
        });
        }
    });

    $("#projectForm").submit(function(e) {
        e.preventDefault();
        if(validation()){
            return;
        }else{
        $.post("projectSave.php", $(this).serialize(), function(response) {
            alert(response);
            $("#projectForm")[0].reset();
            $("#project_id").val("");
            loadProjectList();
        });
        }
    });

    function loadProjectList(){
        $.ajax({
            url: "getProject.php",
            type: "GET",
            dataType:"json",
            success: function(data){
                $('#project_name').empty();
                for(var i = 0; i < data.length; i++){
                    $('#project_name').append('<option value="' + data[i].id + '">' + data[i].project_name + '</option>');
                }
            },
            error: function(xhr, status, error){
                console.error("Error: " + error);
            }
        })
    }

    function loadProjects() {
        $.get("fetchProject.php", function(data) {
            $("#projectTable").html(data);
        });
    }


    // Load Students
    function loadEmployees() {
        $.get("fetch.php", function(data) {
            $("#employeeTable").html(data);
        });
    }

    function validation(){
        var hourz = parseInt($("#hourz").val());
        var rate = parseInt($("#rate").val());
        if (hourz <0 || rate < 0){
            alert("Hours Worked or the Rate Cannot be Negative number");
            return true;
        }
    }

    // Edit Student (Load details into form)
    $(document).on("click", ".editBtn", function() {
        $("#employee_id").val($(this).data("id"));
        $("#employee_name").val($(this).data("employee_name"));
        $("#position").val($(this).data("position"));
        $("#hourz").val($(this).data("hourz"));
        $("#rate").val($(this).data("rate"));
        $("#salary").val($(this).data("salary"));
        
    });

    // Delete Student
    $(document).on("click", ".deleteBtn", function() {
        if (confirm("Are you sure?")) {
            $.post("delete.php", { id: $(this).data("id") }, function(response) {
                alert(response);
                loadEmployees();
            });
        }
    });

    // Reset Form
    $("#resetForm").click(function() {
        $("#employeeForm")[0].reset();
        $("#employee_id").val("");
    });
});