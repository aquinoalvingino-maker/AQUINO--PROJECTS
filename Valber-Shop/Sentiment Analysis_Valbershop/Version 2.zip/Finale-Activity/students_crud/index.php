<?php include "config.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <nav class="navbar">
    <ul>
      <li><a href="index.php" class="magnet">Employees</a></li>
      <li><a href="projects.php" class="magnet">Projects</a></li>
    </ul>
  </nav>
</head>
<body>
    <div class="animated-bg">
    <div class="container mt-4">
         <br><br><br><br>

        <div class="first">
        <div class="card p-3">
        <h1 class="text-center">Employee Salary System</h1>
            <h5>Add Employee</h5>
            <form id="employeeForm">
                <input type="hidden" name="employee_id" id="employee_id"/>
                <div class="mb-2">
                    <label>Employee Name</label>
                    <input type="text" id="employee_name" class="form-control" name="employee_name" required>
                </div>
                <div class="mb-2">
                    <label>Position</label>
                    <input type="select" id="position" class="form-control" name="position" required>
                </div>

                <div class="mb-2">
                    <label>Projects</label>
                    <select id="project_name" name="project_name">
                      <option value=""></option>
                    </select>
                </div>
               
                <div class="mb-2">
                    <label>Hours Work</label>
                    <input type="number" id="hourz" class="form-control" name="hourz" required>
                </div>

                <div class="mb-2">
                    <label>Rate Per Hour</label>
                    <input type="number" id="rate" class="form-control" name="rate" required>
                </div>
                
                <!-- <div class="mb-2">
                    <label>Salary</label>
                    <input type="text" id="salary" class="form-control" name="salary" placeholder="Total" disabled>
                </div> -->

                </div>
                <button type="submit" class="btn btn-primary">Add Employee</button>
            </form>
        </div>
        <div>

        <h5 class="mt-4">Employee List</h5>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Employee Name</th>
                    <th>Position</th>
                    <th>Project Name</th>
                    <th>Hours Work</th>
                    <th>Rate Per Hour</th>
                    <th>Total Salary</th>
                </tr>
            </thead>
            <tbody id="employeeTable">
                <!-- Student list will be loaded here via AJAX -->
            </tbody>
        </table>
    </div>
</div>

    <script src="script/script.js"></script>

    <style>
*,
::before,
::after {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}

@keyframes rotate-orb {
  100% {
    transform:
            /* GPU Context Activation */ translate3d(0, 0, 0)
      rotate(360deg);
  }
}

.animated-bg {
  width: 100%;
  height: 100%;
  position: fixed;
  z-index: -1;
  background: black
    url(https://cdn.pixabay.com/photo/2022/12/03/12/42/lantern-7632609_1280.jpg)
    center/ cover no-repeat;
  overflow: hidden;
}

.animated-bg span {
  width: 1vmax;
  height: 1vmax;
  border-radius: 50%;
  position: absolute;
  animation: rotate-orb;
  animation-timing-function: linear;
  animation-iteration-count: infinite;
  box-shadow: 2vmax 0 1vmin currentColor;
  color: #ff7300;
}

.animated-bg span:nth-child(1) {
  scale: 200%;
  animation-duration: 12s;
  top: 0;
  left: 0;
  transform-origin: 15vw 20vh;
}

.animated-bg span:nth-child(2) {
  scale: 200%;
  animation-duration: 10s;
  top: 100%;
  left: 0;
  transform-origin: 15vw 20vh;
}

.animated-bg span:nth-child(3) {
  scale: 200%;
  animation-duration: 15s;
  top: 0;
  left: 100%;
  transform-origin: 15vw 20vh;
}

.animated-bg span:nth-child(4) {
  scale: 200%;
  animation-duration: 15s;
  top: 100%;
  left: 100%;
  transform-origin: 35vw 15vh;
}

.animated-bg span:nth-child(5) {
  scale: 150%;
  animation-duration: 15s;
  top: 0;
  left: 50%;
  transform-origin: 0 40vh;
}

.animated-bg span:nth-child(6) {
  scale: 150%;
  animation-duration: 15s;
  top: 100%;
  left: 50%;
  transform-origin: 20vw -35vh;
}

.animated-bg span:nth-child(7) {
  scale: 150%;
  animation-duration: 20s;
  top: 50%;
  left: 0;
  transform-origin: 25vw 10vh;
}

.animated-bg span:nth-child(8) {
  scale: 150%;
  animation-duration: 15s;
  top: 50%;
  left: 100%;
  transform-origin: 20vw 0;
}

.animated-bg span:nth-child(9) {
  scale: 100%;
  animation-duration: 30s;
  top: 0;
  left: 0;
  transform-origin: 10vw 30vh;
}

.animated-bg span:nth-child(10) {
  scale: 100%;
  animation-duration: 25s;
  top: 100%;
  left: 0;
  transform-origin: 30vw -10vh;
}

.animated-bg span:nth-child(11) {
  scale: 100%;
  animation-duration: 30s;
  top: 0;
  left: 100%;
  transform-origin: -10vw 20vh;
}

.animated-bg span:nth-child(12) {
  scale: 100%;
  animation-duration: 35s;
  top: 100%;
  left: 100%;
  transform-origin: -20vw -20vh;
}

.animated-bg span:nth-child(13) {
  scale: 75%;
  animation-duration: 40s;
  top: 25%;
  left: 25%;
  transform-origin: -15vw -5vh;
}

.animated-bg span:nth-child(14) {
  scale: 75%;
  animation-duration: 40s;
  top: 75%;
  left: 0;
  transform-origin: 15vw 5vh;
}

.animated-bg span:nth-child(15) {
  scale: 75%;
  animation-duration: 45s;
  top: 0;
  left: 100%;
  transform-origin: -15vw 15vh;
}

.animated-bg span:nth-child(16) {
  scale: 75%;
  animation-duration: 40s;
  top: 100%;
  left: 100%;
  transform-origin: -10vw -20vh;
}

.animated-bg span:nth-child(17) {
  scale: 50%;
  animation-duration: 50s;
  top: 0;
  left: 0;
  transform-origin: 40vw 25vh;
}

.animated-bg span:nth-child(18) {
  scale: 50%;
  animation-duration: 50s;
  top: 100%;
  left: 0;
  transform-origin: 30vw -20vh;
}

.animated-bg span:nth-child(19) {
  scale: 50%;
  animation-duration: 50s;
  top: 0;
  left: 100%;
  transform-origin: -20vw 20vh;
}

.animated-bg span:nth-child(20) {
  scale: 50%;
  animation-duration: 50s;
  top: 100%;
  left: 100%;
  transform-origin: -30vw -10vh;
}

.first{
background: yellow;
justify-content: center;
color: yellow;
align: center;
}

.table{
    background: white;
    border: ;
}

.mt-4{
color: white;
align: center;
}

head {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #222;
    color: #fff;
    text-align: center;
  }

  .navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background: rgba(0, 0, 0, 0.8);
    padding: 15px 0;
    text-align: center;
  }

  .navbar ul {
    list-style: none;
    display: flex;
    justify-content: center;
    gap: 30px;
    padding: 0;
    margin: 0;
  }

  .navbar ul li a {
    position: relative;
    font-size: 22px;
    color: #fff;
    text-decoration: none;
    text-transform: uppercase;
    font-weight: bold;
    display: inline-block;
    padding: 10px 15px;
    transition: color 0.3s ease;
  }
  .magnet:hover {
 color: yellow;
  }


        </style>
</body>
</html>