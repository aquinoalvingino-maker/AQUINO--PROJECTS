<?php
include "config.php";
$id = $_POST['employee_id'] ?? null;
$project_id = $_POST['project_id'] ?? null;
$employee_name = $_POST['employee_name'];
$position = $_POST['position'];
$hourz = $_POST['hourz'];
$rate = $_POST['rate'];
$salary = $hourz * $rate;
$project_name = $_POST['project_name'];


if ($id) {
    $query = "UPDATE employee SET employee_name='$employee_name', position='$position', project_name='$project_name', hourz='$hourz', rate='$rate', salary='$salary' WHERE id = '$id'";
} else {
    $query = "INSERT INTO employee (employee_name, position, project_name, hourz, rate, salary) VALUES('$employee_name', '$position', '$project_name', '$hourz', '$rate', '$salary')";
   
}

if ($conn->query($query)) {
    $employee_id = $conn->insert_id;
    $project_id = $conn->insert_id;
    $query = "INSERT INTO project_list (employee_id, project_id, hourz, salary) VALUES('$employee_id', '$project_id', '$hourz', '$salary')";

    if ($conn->query($query)){
        echo "success";
    }
    else 
    {
    echo "Error: " . $conn->error;
    }
    
echo "Employee saved successfully!";

} else {
    echo "Error: " . $conn->error;

}

?>