<?php
include "config.php";

$query = "SELECT * FROM employee ORDER BY salary DESC";
$result = $conn->query($query);

$output = "";
while ($row = $result->fetch_assoc()) {
    $output .= "
        <tr>
            <td>{$row['id']}</td>
            <td>{$row['employee_name']}</td>
            <td>{$row['position']}</td>
            <td>{$row['project_name']}</td>
            <td>{$row['hourz']}</td>
            <td>{$row['rate']}</td>
            <td>{$row['salary']}</td>
            <td>
                <button class='btn btn-warning btn-sm editBtn' data-id='{$row['id']}' data-employee_name='{$row['employee_name']}' data-position='{$row['position']}' data-project_name='{$row['project_name']}' data-hourz='{$row['hourz']}' data-rate='{$row['rate']}' data-salary='{$row['salary']}'>Edit</button>
                <button class='btn btn-danger btn-sm deleteBtn' data-id='{$row['id']}'>Delete</button>
            </td>
        </tr>";
}

echo $output;
?>