<?php 
include "config.php";
$query = "SELECT * FROM projects ORDER by id DESC";
$result = $conn->query($query);

$projects = [];

while($row = $result->fetch_assoc()){
    $projects[] = $row;;
}

echo json_encode($projects);
?>