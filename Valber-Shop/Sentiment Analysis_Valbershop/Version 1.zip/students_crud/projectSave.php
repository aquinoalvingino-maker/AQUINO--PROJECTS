<?php
include "config.php";

$id = $_POST['id'] ?? null;
$project_name = $_POST['project_name'];


if ($id) {
    $query = "UPDATE projects SET project_name='$project_name' WHERE id = '$id'";
} else {
    $query = "INSERT INTO projects (project_name) VALUES('$project_name')";
}

if ($conn->query($query)) {
        echo "Employee Saved and Project entry created successfully";
} else {
    echo "Error: " . $conn->error;

}

?>