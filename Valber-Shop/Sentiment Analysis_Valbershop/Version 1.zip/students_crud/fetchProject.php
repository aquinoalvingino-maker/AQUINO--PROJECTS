<?php
include "config.php";

$query = "SELECT * FROM projects ORDER BY project_name DESC";
$result = $conn->query($query);

$output = "";
while ($row = $result->fetch_assoc()) {
    $output .= "
        <tr>
            <td>{$row['id']}</td>
            <td>{$row['project_name']}</td>
            <td>
                <button class='btn btn-warning btn-sm editBtn' data-id='{$row['id']}' data-project_name='{$row['project_name']}'>Edit</button>
                <button class='btn btn-danger btn-sm deleteBtn' data-id='{$row['id']}'>Delete</button>
            </td>
        </tr>";
}

echo $output;
?>