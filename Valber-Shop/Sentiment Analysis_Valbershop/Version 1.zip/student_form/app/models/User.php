<?php
require_once __DIR__ . '/../../config/database.php';

class User  {
    public static function getAll() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM users");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function add($first_name,$last_name,$birthdate,$email,$passwords,$confirmed_passwords,$contact_number,$address) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO users (first_name,last_name,birthdate,email,passwords,confirmed_passwords,contact_number,address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$first_name,$last_name,$birthdate,$email,$passwords,$confirmed_passwords,$contact_number,$address]);
    }
}
?>
