<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Form</title>
    <link rel="stylesheet" href="design.css">
</head>
<body>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">


            <!-- <h2 class="right-container__h2">Nice to see you!</h2>
            <p class="right-container__p">Enter your email and password to sign in</p> -->
       
            <div class="container">
            <div class="bg"></div>
        <form method="POST" action="../controllers/LoginController.php">
            <div class="input-container"><br><br><bn><br><br><hr>
                <label for="email" class="right-container__label">Email</label>
                <input type="text" class="right-container__input" id="email" name="email" placeholder="Your email address" required>

                <label for="password" class="right-container__label">Password</label>
                <input type="password" id="password" class="right-container__input" name="password" placeholder="Your password" required> 
                
            </div> 
            <button type="submit" id="btnLogin" class="btnLogin">SIGN IN</button><br><br>
        

        <hr>
        <p>Don't have an account?</p>
        <a href="app/views/student_form.php" class="sgnup">Sign Up?</a>
      

<a href="../../index.php">Back to List</a>
</form>
</div>
</body>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap');

* { margin: 0; padding: 0; box-sizing: border-box; }
*:focus { outline: none; }
body {
    width: 100%;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-image: url('https://i.postimg.cc/nz6YzMPg/background.jpgs');
    background-size: cover;
    font-family: 'Roboto';
}
.container { 
    width: 800px; 
    height: 500px; 
    display: flex; 
    justify-content: center; 
    align-items: center; 
    background: #FFF; 
    box-shadow: 0 0 10px rgba(0, 0, 0, .1); 
    overflow: hidden; 
    position: relative; 
    border: 10px solid #FFF; 
    border-radius: 10px; 
}
.bg { 
    width: 50%; 
    height: 100%; 
    background-image: url('https://i.postimg.cc/nz6YzMPg/background.jpgs'); 
    background-size: cover; 
    border-top-left-radius: 5px; 
    border-bottom-left-radius: 5px; 
    position: relative; 
}
    .bg::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2;
        background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, rgba(255, 140, 0, .5) 100%);
    }
form { min-width: 250px !important; width: 50%; height: 100%; padding: 30px 20px; }
.heading { font-size: 40px; text-transform: capitalize; margin-bottom: 60px; text-align: center; }
label { font-size: 16px; display: block; margin: 10px 0; text-transform: capitalize; }
input {font-size: 16px; display: block; width: 90%; border: none; border-bottom: 1px solid #000; margin-bottom: 20px; }
.login-btn {
    width: 130px;
    height: 30px;
    text-transform: capitalize;
    border-radius: 50px;
    border: none;
    background: orange;
    color: #FFF;
    display: block;
    cursor: pointer;
    margin: 50px auto;
}
.register-btn { font-size: 14px; color: rgb(117, 117, 117); text-transform: capitalize; position: absolute; bottom: 20px; right: 20px; cursor: pointer; }

@media screen and (max-width: 750px) {
    .container { width: 350px; }
    .bg { display: none; }
    form { display: 100%; }
}
</style>
</html>

