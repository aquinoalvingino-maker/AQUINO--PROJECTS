<?php 
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login_form.php");
    exit();
}

$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="design.css">
    <title>LogIn Form</title>
</head>
<body>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
<div class="left-container">
</div>
<div class="right-container">
    <div class="right-container__box">
        <div class="right-container-box">
            <h2 class="right-container__h2">welcome</h2>
            <p class="right-container__p">Enter your email and password to sign in</p>
        
    </div>
</div>
    <a href="../../index.php">Back to List</a>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
