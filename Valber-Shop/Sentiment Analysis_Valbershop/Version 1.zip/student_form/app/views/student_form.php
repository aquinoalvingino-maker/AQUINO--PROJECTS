<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Form</title>
    <link rel="stylesheet" href="design.css">
</head>
<body>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
<div class="left-container">
</div>
<div class="right-container">
    <div class="right-container__box">
        <div class="right-container-box">
    <h2>Add Student</h2>
    <form action="../controllers/StudentController.php" method="POST">
        <label>First Name:</label>
        <input type="text" name="first_name" id="first_name"><br><br>
        <label>Last Name:</label>
        <input type="text" name="last_name" id="last_name"><br><br>
        <label>Birthdate:</label>
        <input type="date" name="birthdate" id="birthdate"><br><br>
        <label>Email:</label>
        <input type="email" name="email" id="email"><br><br>
        <label>Password:</label>
        <input type="password" name="passwords" id="passwords"><br><br>
        <label>Confirm Password:</label>
        <input type="password" name="confirmed_passwords" id="confirmed_passwords"><br><br>
        <label>Contact Number:</label>
        <input type="text" name="contact_number" id="contact_number"><br><br>
        <label>Address:</label>
        <input type="text" name="address" id="address"><br><br>
        <hr>
        <button type="submit">submit</button>

</div>
</div>
</div>
    </form>
    <a href="../../index.php">Back to List</a>
</body>
</html>
