<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student List</title>
</head>
<body>
    <h2>Student List</h2>
    <a href="app/views/student_form.php">Add New Student</a>
    <ul>
        <?php foreach ($users as $user): ?>
            <li><?php echo $user['first_name'] . " - " . $user['last_name'] . " - " .  $user['birthdate'] ." - ". $user['email'] ." - " . $user['passwords'] . " - " . $user['confirmed_passwords'] . " - " . $user['contact_number'] . " - " . $user['address']; ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
