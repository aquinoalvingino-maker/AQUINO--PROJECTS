<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../models/User.php';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $birthdate = $_POST['birthdate'] ?? '';
    $email = $_POST['email'] ?? '';
    $passwords = $_POST['passwords'] ?? '';
    $confirmed_passwords = $_POST['confirmed_passwords'] ?? '';
    $contact_number = $_POST['contact_number'] ?? '';
    $address = $_POST['address'] ?? '';
    $takenusername = "";

    // if($username === $takenusername){
    //     $errors[] = "Username is already taken";
    // }


    // if($password != $confirmed_passwords){
    //     $errors[] = "Confirmed password and password should match";
    // }


    // if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    //     $errors[] = "Invalid email format.";
    // }

    // if(strlen($contact_number <11)) {
    //     $errors[] = "Username must be at least 11 digits";
    // }

    // if(empty($errors)){
    //     echo "<h4>Registration Successful</h4>";
    // }
    // else{
    //     echo "<h1>Registration Failed</h1>";
    //     foreach ($errors as $error) { 
    //         echo "<li>$error</li>"; 
    //     } 
    // }
    if (!empty($last_name)) {
       
        // echo $last_name;
        // die();
        User::add($first_name,$last_name,$birthdate,$email,$passwords,$confirmed_passwords,$contact_number,$address);
        // Student::add("Alice Brown", "alice@example.com", 21);
    }else{
        echo "hindi kumpleto";
    }

}

$users = User::getAll();
require_once __DIR__ . '/../views/login_form.php';
?>
