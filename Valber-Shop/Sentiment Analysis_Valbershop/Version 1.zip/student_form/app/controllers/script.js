$(document).ready(function() {
    loadEmployees();

    // Add or Update Student
    $("#employeeForm").submit(function(e) {
        e.preventDefault();
        if(validation()){
            return;
        }else{
        $.post("save.php", $(this).serialize(), function(response) {
            alert(response);
            $("#employeeForm")[0].reset();
            $("#employee_id").val("");
            loadEmployees();
        });
        }
    });

    // Load Students
    function loadEmployees() {
        $.get("fetch.php", function(data) {
            $("#employeeTable").html(data);
        });
    }

    function validation(){
        var hourz = parseInt($("#hourz").val());
        var rate = parseInt($("#rate").val());
        if (hourz <0 || rate < 0){
            alert("Hours Worked or the Rate Cannot be Negative number");
            return true;
        }
    }

    // Edit Student (Load details into form)
    $(document).on("click", ".editBtn", function() {
        $("#employee_id").val($(this).data("id"));
        $("#employee_name").val($(this).data("employee_name"));
        $("#position").val($(this).data("position"));
        $("#hourz").val($(this).data("hourz"));
        $("#rate").val($(this).data("rate"));
        $("#salary").val($(this).data("salary"));
        
    });

    // Delete Student
    $(document).on("click", ".deleteBtn", function() {
        if (confirm("Are you sure?")) {
            $.post("delete.php", { id: $(this).data("id") }, function(response) {
                alert(response);
                loadEmployees();
            });
        }
    });

    // Reset Form
    $("#resetForm").click(function() {
        $("#employeeForm")[0].reset();
        $("#employee_id").val("");
    });
});