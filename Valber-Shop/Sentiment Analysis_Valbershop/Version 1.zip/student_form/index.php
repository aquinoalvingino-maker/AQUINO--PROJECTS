<?php
require_once __DIR__ . '/app/controllers/StudentController.php';
?>
